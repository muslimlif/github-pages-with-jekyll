
# Official Facebook Pixel

Grow your business with Official Facebook Pixel! This plugin will install a 
Facebook Pixel on your Drupal site, detect and fire pixel events automatically!

## Get started

Download the zip file marked 'official-facebook-pixel-8.x-[version number].zip' attached to the current release.

## Requirements

Official Facebook Pixel requires
* Drupal 8.x
* PHP 5.6 or greater

## License

Official Facebook Pixel is GPLv2-licensed.
